//
//  SplashViewController.m
//  HealthInformation
//
//  Created by Ramesh Patel on 3/10/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "SplashViewController.h"
#import "HealthInformationViewController.h"
@implementation SplashViewController
@synthesize progressBar,webData,soapResults,xmlParser;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    

}

- (void)viewDidUnload
{
    [self setProgressBar:nil];
    [activity release];
    activity = nil;
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
//    [NSTimer scheduledTimerWithTimeInterval:3 target:self selector:@selector(splash) userInfo:nil repeats:NO];
    delegate = [[UIApplication sharedApplication] delegate];
    // Do any additional setup after loading the view from its nib.
    [activity startAnimating];
    if ([delegate isConnected]) 
    {
        NSData *htmlData = [[NSString stringWithContentsOfURL:[NSURL URLWithString: @"http://www.nlm.nih.gov/medlineplus/xml.html"]] dataUsingEncoding:NSUTF8StringEncoding];
        TFHpple *xpathParser = [[TFHpple alloc] initWithHTMLData:htmlData];		
        NSArray *elements  = [xpathParser search:@"//a"]; 
        
        // get the page title
        for (int i=0;i<elements.count; i++) {
            
            
            TFHppleElement *element = [elements objectAtIndex:i];
            NSString *h3Tag = [element content]; 
            if ([h3Tag isEqualToString:@"Complete MedlinePlus Vocabulary and Summaries XML"])
            {
                NSLog(@"link%@",[[element attributes] valueForKey:@"href"]);
                strCompletedataUrl = [NSString stringWithString:[[element attributes] valueForKey:@"href"]];
                
            }
            if ([h3Tag isEqualToString:@"MedlinePlus Vocabulary and Summaries Delta XML"]) 
            {
                NSLog(@"links:%@",[[element attributes] valueForKey:@"href"]);
                strModifiDataUrl = [NSString stringWithFormat:@"%@",[[element attributes] valueForKey:@"href"]];
                [strModifiDataUrl retain];
                break;
            }
            
        }

    }
    else
    {
        
		UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Error Loading" message:@"No Internet connection." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		[alert show];
		[alert release];
    }

    if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"download"] isEqualToString:@"YES"])
    {
    [self getUpdateData];
    }
    else
    {
    [self getCount];
    }

}

-(void)getCount
{
    getUpgate = NO;
     recordResults=FALSE;
    if ([delegate isConnected]) 
    {  
        //        NSURL *url = [NSURL URLWithString:@"http://wsearch.nlm.nih.gov/ws/query?db=healthTopics"];
        
        NSURL *url = [NSURL URLWithString:strCompletedataUrl];
        NSLog(@"%@",url);
        NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url];
        
        
        NSURLConnection *theConnection = [[NSURLConnection alloc] initWithRequest:theRequest delegate:self];
        
        if( theConnection )
        {
            webData = [[NSMutableData data] retain];
            //            [theConnection release];
        }
        else
        {
            NSLog(@"theConnection is NULL");
        }
        
    }
    else
    {
        
		UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Error Loading" message:@"No Internet connection." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		[alert show];
		[alert release];
    }
    
    
}

-(void)getUpdateData
{
    
    getUpgate = YES;
    recordResults=FALSE;
    if ([delegate isConnected]) 
    {  
        //        NSURL *url = [NSURL URLWithString:@"http://wsearch.nlm.nih.gov/ws/query?db=healthTopics"];
        NSLog(@"modifiedurl:%@",strModifiDataUrl);
        NSURL *url = [NSURL URLWithString:strModifiDataUrl];
        NSLog(@"%@",url);
        NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url];
        
        
        NSURLConnection *theConnection = [[NSURLConnection alloc] initWithRequest:theRequest delegate:self];
        
        if( theConnection )
        {
            webData = [[NSMutableData data] retain];
            //            [theConnection release];
        }
        else
        {
            NSLog(@"theConnection is NULL");
        }
        
    }
    else
    {
        
		UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Error Loading" message:@"No Internet connection." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		[alert show];
		[alert release];
    }

}
-(void)splash
{
    HealthInformationViewController *objHealthInformationViewController = [[HealthInformationViewController alloc]initWithNibName:@"HealthInformationViewController" bundle:nil];
    objHealthInformationViewController.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
//    [UIView transitionFromView:self.view
//                        toView:objHealthInformationViewController.view
//                      duration:0.9f
//                       options:UIViewAnimationOptionTransitionFlipFromLeft
//                    completion:nil];
//    [self.view addSubview:objHealthInformationViewController.view];
    [self presentModalViewController:objHealthInformationViewController animated:YES];
    [objHealthInformationViewController release];
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
#pragma mark - xmlParserDelegate method

-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
	[webData setLength: 0];
     size = [[NSString stringWithFormat:@"%lli",[response expectedContentLength]] floatValue];
    NSLog(@"Size : %f",size);
}
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    NSLog(@"GEtData");
	[webData appendData:data];
    totalDownloadedData += [data length]; // global integer
    progressBar.progress = totalDownloadedData/size;
    NSLog(@"Status : %d",totalDownloadedData);
    float temp = (totalDownloadedData*100)/size;
    NSLog(@"%f",temp);
}
-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    NSLog(@"ERROR with theConenction");
    [connection release];
	[webData release];
    
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Error Loading" message:@"No Internet connection." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:@"Retry",nil];
		[alert show];
		[alert release];
    
}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex==1) {
        [self viewWillAppear:YES];
    }
}
-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    
	NSLog(@"DONE. Received Bytes: %d", [webData length]);
    	NSString *theXML = [[NSString alloc] initWithBytes: [webData mutableBytes] length:[webData length] encoding:NSUTF8StringEncoding];
	NSLog(@"%@",theXML);
	[theXML release];
	
	if( xmlParser )
	{
		[xmlParser release];
	}
	
	xmlParser = [[NSXMLParser alloc] initWithData: webData];
	[xmlParser setDelegate:self];
	[xmlParser setShouldResolveExternalEntities: YES];
	[xmlParser parse];
	
	[connection release];
	
}

-(void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *) namespaceURI qualifiedName:(NSString *)qName
   attributes: (NSDictionary *)attributeDict
{
    
        
    if (getUpgate ==NO) 
    {
        if( [elementName isEqualToString:@"MedicalTopics"])
        {
            if(!soapResults)
            {
                soapResults = [[NSMutableString alloc] init];
                
            }
            recordResults = TRUE;
        }
        if( [elementName isEqualToString:@"MedicalTopic"])
        {
            
            if ([attributeDict valueForKey:@"langcode"])
            {
                
                strLangageCode = [NSString stringWithFormat:@"%@",[attributeDict valueForKey:@"langcode"]];
                
                if(!soapResults)
                {
                    soapResults = [[NSMutableString alloc] init];
                }
            }
            recordResults = TRUE;
        }
        
        
        if( [elementName isEqualToString:@"ID"])
        {
            if(!soapResults)
            {
                soapResults = [[NSMutableString alloc] init];
                
            }
            recordResults = TRUE;
        }
        
        if( [elementName isEqualToString:@"MedicalTopicName"])
        {
            if(!soapResults)
            {
                soapResults = [[NSMutableString alloc] init];
                
            }
            recordResults = TRUE;
        }
        
        if( [elementName isEqualToString:@"URL"])
        {
            if(!soapResults)
            {
                soapResults = [[NSMutableString alloc] init];
                
            }
            recordResults = TRUE;
        }
        
        if( [elementName isEqualToString:@"FullSummary"])
        {
            if(!soapResults)
            {
                soapResults = [[NSMutableString alloc] init];
                
            }
            recordResults = TRUE;
        }
        if( [elementName isEqualToString:@"LanguageMappedTopicID"])
        {
            if(!soapResults)
            {
                soapResults = [[NSMutableString alloc] init];
                
            }
            recordResults = TRUE;
        }
    }
    else
    {
        if( [elementName isEqualToString:@"MedicalTopics"])
        {
            if ([attributeDict valueForKey:@"totalEnglish"])
            {
                
                strUpdateCount= [NSString stringWithFormat:@"%@",[attributeDict valueForKey:@"totalEnglish"]];
                
                if(!soapResults)
                {
                    soapResults = [[NSMutableString alloc] init];
                }
            }
            recordResults = TRUE;
        }
        if( [elementName isEqualToString:@"MedicalTopic"])
        {
            
            if ([attributeDict valueForKey:@"langcode"])
            {
                
                strLangageCode = [NSString stringWithFormat:@"%@",[attributeDict valueForKey:@"langcode"]];
                strUpdateStatus = [NSString stringWithFormat:@"%@",[attributeDict valueForKey:@"status"]];
                if(!soapResults)
                {
                    soapResults = [[NSMutableString alloc] init];
                }
            }
            recordResults = TRUE;
        }
        
        
        if( [elementName isEqualToString:@"ID"])
        {
            if(!soapResults)
            {
                soapResults = [[NSMutableString alloc] init];
                
            }
            recordResults = TRUE;
        }
        
        if( [elementName isEqualToString:@"MedicalTopicName"])
        {
            if(!soapResults)
            {
                soapResults = [[NSMutableString alloc] init];
                
            }
            recordResults = TRUE;
        }
        
        if( [elementName isEqualToString:@"URL"])
        {
            if(!soapResults)
            {
                soapResults = [[NSMutableString alloc] init];
                
            }
            recordResults = TRUE;
        }
        
        if( [elementName isEqualToString:@"FullSummary"])
        {
            if(!soapResults)
            {
                soapResults = [[NSMutableString alloc] init];
                
            }
            recordResults = TRUE;
        }
        if( [elementName isEqualToString:@"LanguageMappedTopicID"])
        {
            if(!soapResults)
            {
                soapResults = [[NSMutableString alloc] init];
                
            }
            recordResults = TRUE;
        }

    }
        
    
        
    
}
-(void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
	if( recordResults )
	{
        [soapResults appendString:string];
	}
}
-(void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
      
    if (getUpgate==NO)
    {
        if ([strLangageCode isEqualToString:@"English" ]) 
        {
            if( [elementName isEqualToString:@"ID"])
            {
                //                NSLog(@"ID : %@",soapResults);
                strID = [NSString stringWithString:soapResults];
                strID = [strID stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                [soapResults release];
                soapResults = nil;
                recordResults = FALSE;
            }
            if( [elementName isEqualToString:@"MedicalTopicName"])
            {
                //            strCount = [NSString stringWithString:soapResults];
                //                NSLog(@"MedicalTopicName = %@",soapResults);
                
                strTopic = [NSString stringWithString:soapResults];
                [soapResults release];
                soapResults = nil;
                recordResults = FALSE;
            }
            
            if( [elementName isEqualToString:@"URL"])
            {
                //                NSLog(@"URL = %@",soapResults);
                strUrl = [NSString stringWithString:soapResults];
                [soapResults release];
                soapResults = nil;
                recordResults = FALSE;
                
            }
            
            if( [elementName isEqualToString:@"FullSummary"])
            {
                strSummury = [NSString stringWithString:soapResults];
                //                strSummury = [strSummury stringBya];
                //                NSLog(@"summry:%@",soapResults);
                [soapResults release];
                soapResults = nil;
                recordResults = FALSE;
                
            }
            
            if( [elementName isEqualToString:@"LanguageMappedTopicID"])
            {
                [soapResults release];
                soapResults = nil;
                recordResults = FALSE;
                NSArray *documentPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
                NSString *documentsDir = [documentPaths objectAtIndex:0];
                NSString *databasePath=[documentsDir stringByAppendingPathComponent:@"health_db.sqlite"];
                if(sqlite3_open([databasePath UTF8String], &database) == SQLITE_OK)
                {
//                    NSLog(@"%@\\",strID);
                    //                           NSString *insertSQL = [NSString stringWithFormat:@"INSERT INTO health_topic (url,id,summary,topic) values (\"%@\",\"%@\",\"%@\",\"%@\");",strUrl,strID,strSummury,strTopic];
                    NSString *insertSQL = [NSString stringWithFormat:@"INSERT INTO health_topic (url,id,summary,topic) values (?,?,?,?);"];
                    
                    const char *insert_stmt = [insertSQL UTF8String];
                    //                    sqlite3_exec(database, [insertSQL UTF8String], NULL, NULL, NULL);
                    if(sqlite3_prepare_v2(database, insert_stmt, -1, &statement, nil)== SQLITE_OK)
                    {
                        sqlite3_bind_text( statement, 1, [strUrl UTF8String], -1, SQLITE_TRANSIENT);
                        sqlite3_bind_text( statement, 2, [strID UTF8String], -1, SQLITE_TRANSIENT);
                        sqlite3_bind_text( statement, 3, [strSummury UTF8String], -1, SQLITE_TRANSIENT);
                        sqlite3_bind_text( statement, 4, [strTopic UTF8String], -1, SQLITE_TRANSIENT);
                    }
                    else
                    {
                        NSLog(@"Error Preparing Statement: %s", sqlite3_errmsg(database));
                    }
                    
                    if(sqlite3_step(statement)==SQLITE_DONE) 
                    {
                        //                        NSLog(@"databese addd");
                    }
                    else 
                    {
                        //                        NSLog(@"not insert");
                    }   
                    // Release the compiled statement from memory
                    sqlite3_finalize(statement);    
                    sqlite3_close(database);
                    
                    
                }
            }
            
        }
        else
        {
            [soapResults release];
            soapResults = nil;
            recordResults = FALSE;
        }
        if( [elementName isEqualToString:@"MedicalTopics"])
        {
            [soapResults release];
            soapResults = nil;
            recordResults = FALSE;
            [[NSUserDefaults standardUserDefaults] setObject:@"YES" forKey:@"download"];
            
            [self getUpdateData];
            
        }

        
    }
    else
    {
        
        if ([strUpdateCount intValue]>0)
        {
            if ([strLangageCode isEqualToString:@"English" ]&&[strUpdateStatus isEqualToString:@"modified"]) 
            {
                if( [elementName isEqualToString:@"ID"])
                {
                    //                NSLog(@"ID : %@",soapResults);
                    strID = [NSString stringWithString:soapResults];
                    strID = [strID stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                    [soapResults release];
                    soapResults = nil;
                    recordResults = FALSE;
                }
                if( [elementName isEqualToString:@"MedicalTopicName"])
                {
                    //            strCount = [NSString stringWithString:soapResults];
                    //                NSLog(@"MedicalTopicName = %@",soapResults);
                    
                    strTopic = [NSString stringWithString:soapResults];
                    [soapResults release];
                    soapResults = nil;
                    recordResults = FALSE;
                }
                
                if( [elementName isEqualToString:@"URL"])
                {
                    //                NSLog(@"URL = %@",soapResults);
                    strUrl = [NSString stringWithString:soapResults];
                    [soapResults release];
                    soapResults = nil;
                    recordResults = FALSE;
                    
                }
                
                if( [elementName isEqualToString:@"FullSummary"])
                {
                    strSummury = [NSString stringWithString:soapResults];
                    //                strSummury = [strSummury stringBya];
                    //                NSLog(@"summry:%@",soapResults);
                    [soapResults release];
                    soapResults = nil;
                    recordResults = FALSE;
                    
                }
                
                if( [elementName isEqualToString:@"LanguageMappedTopicID"])
                {
                    [soapResults release];
                    soapResults = nil;
                    recordResults = FALSE;
                    NSArray *documentPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
                    NSString *documentsDir = [documentPaths objectAtIndex:0];
                    NSString *databasePath=[documentsDir stringByAppendingPathComponent:@"health_db.sqlite"];
                    if(sqlite3_open([databasePath UTF8String], &database) == SQLITE_OK)
                    {
                        NSLog(@"%@\\",strID);
                        //                           NSString *insertSQL = [NSString stringWithFormat:@"INSERT INTO health_topic (url,id,summary,topic) values (\"%@\",\"%@\",\"%@\",\"%@\");",strUrl,strID,strSummury,strTopic];
                        NSString *insertSQL = [NSString stringWithFormat:@"UPDATE health_topic set url=?,summary=?,topic=? where id = ?;"];
//                        update Coffee Set CoffeeName = ?, Price = ? Where CoffeeID = ?
                        const char *insert_stmt = [insertSQL UTF8String];
                        //                    sqlite3_exec(database, [insertSQL UTF8String], NULL, NULL, NULL);
                        if(sqlite3_prepare_v2(database, insert_stmt, -1, &statement, nil)== SQLITE_OK)
                        {
                            sqlite3_bind_text( statement, 1, [strUrl UTF8String], -1, SQLITE_TRANSIENT);
                            sqlite3_bind_text( statement, 4, [strID UTF8String], -1, SQLITE_TRANSIENT);
                            sqlite3_bind_text( statement, 2, [strSummury UTF8String], -1, SQLITE_TRANSIENT);
                            sqlite3_bind_text( statement, 3, [strTopic UTF8String], -1, SQLITE_TRANSIENT);
                        }
                        else
                        {
                            NSLog(@"Error Preparing Statement: %s", sqlite3_errmsg(database));
                        }
                        
                        if(sqlite3_step(statement)==SQLITE_DONE) 
                        {
                                                   NSLog(@"databese update");
                        }
                        else 
                        {
                                                   NSLog(@"not update");
                        }   
                        // Release the compiled statement from memory
                        sqlite3_finalize(statement);    
                        sqlite3_close(database);
                        
                        
                    }
                }
                
            }
            else
            {
                [soapResults release];
                soapResults = nil;
                recordResults = FALSE;
            }
            if( [elementName isEqualToString:@"MedicalTopics"])
            {
                [soapResults release];
                soapResults = nil;
                recordResults = FALSE;
                [activity stopAnimating];
                [self splash];
                
                
            }

        }
        
    }
    
    
       
    
    
}

- (void)dealloc {
    [progressBar release];
    [activity release];
    [super dealloc];
}
@end
