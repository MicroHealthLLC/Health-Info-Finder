//
//  HealthInformationViewController.m
//  HealthInformation
//
//  Created by MAC4 on 3/3/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "HealthInformationViewController.h"
#import "OverlayViewController.h"
#import "ContactViewController.h"
#import "TFHpple.h"
//#import "TFHppleElement.h"
int totalDownloadedData;
@implementation HealthInformationViewController
@synthesize btnZoomOut;
@synthesize tollBarView;
@synthesize btnAction;
@synthesize btnGoForward;
@synthesize btnGoBack;
@synthesize imgViewLogo;
@synthesize webview;
@synthesize searchbar;
@synthesize tblView;


@synthesize webData,xmlParser,soapResults;
/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/



// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
    arrTempSummary = [[NSMutableArray alloc] init];
    arrTempTitle =[[NSMutableArray alloc] init];
    arrTempURL=[[NSMutableArray alloc] init];
         
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    delegate = [[UIApplication sharedApplication] delegate];
    arrGettitleList = [[NSMutableArray alloc] init];
    arrSelectedtitleList = [[NSMutableArray alloc] init];
    arrSearchtitleList = [[NSMutableArray alloc] init];
    arrWebViewData = [[NSMutableArray alloc] init];
    arrID = [[NSMutableArray alloc] init];
    
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:HUD];
    HUD.labelText = @"Loading";
    [self.tblView reloadData];
    HUD.delegate = self;
    //    [self getCount];
//    [self getUrls];
    [[[HealthInformationAppDelegate appDelegate] iSpeech] ISpeechSetRecognizeDone:self];
    [self getDataFomDatabase];
    
}
-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
	
	[[[HealthInformationAppDelegate appDelegate] iSpeech] ISpeechSetRecognizeDone:nil];
}
-(void)getUrls
{
    [HUD hide:YES];
    totalDownloadedData = 0;
    [self getCount];
    
}
-(void)getCount
{
    getCount=YES;
    recordResults=FALSE;
    if ([delegate isConnected]) 
    {  
//        NSURL *url = [NSURL URLWithString:@"http://wsearch.nlm.nih.gov/ws/query?db=healthTopics"];
       
        NSURL *url = [NSURL URLWithString:strCompletedataUrl];
        NSLog(@"%@",url);
        NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url];
        
        
        NSURLConnection *theConnection = [[NSURLConnection alloc] initWithRequest:theRequest delegate:self];
        
        if( theConnection )
        {
            webData = [[NSMutableData data] retain];
            //            [theConnection release];
        }
        else
        {
            NSLog(@"theConnection is NULL");
        }

    }
    else
    {
                
		UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Error Loading" message:@"No Internet connection." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		[alert show];
		[alert release];
    }
 
    
}
-(void)getTitleList
{
    getCount=NO;
    getTitle = YES;
    recordResults=FALSE;
    if ([delegate isConnected]) 
    {  
        NSString *strurl = [NSString stringWithFormat:@"http://wsearch.nlm.nih.gov/ws/query?db=healthTopics&retmax=%@",strCount];
        NSURL *url = [NSURL URLWithString:strurl];
        NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url];
        
        
        NSURLConnection *theConnection = [[NSURLConnection alloc] initWithRequest:theRequest delegate:self];
        NSLog(@"%@",strurl);
        if( theConnection )
        {
            webData = [[NSMutableData data] retain];
            //            [theConnection release];
        }
        else
        {
            NSLog(@"theConnection is NULL");
        }
        
    }
    else
    {
        
		UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Error Loading" message:@"No Internet connection." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
		[alert show];
		[alert release];
    }

}
-(void)getDataFomDatabase
{
    sqlite3 *database;
    sqlite3_stmt *statement;
    NSArray *documentPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDir = [documentPaths objectAtIndex:0];
    NSString *databasePath=[documentsDir stringByAppendingPathComponent:@"health_db.sqlite"];
	NSLog(@"%@",databasePath);
	if(sqlite3_open([databasePath UTF8String], &database) == SQLITE_OK)
	{
		//	NSString *insertSQL = [NSString stringWithFormat:@"SELECT * FROM SpeedTrap" ];
		//        NSString *insertSQL = [NSString stringWithFormat: @"INSERT INTO Loginchk (uname,password) VALUES ('%@',' %@');",Gunameq,Gpassq];
		//const char *insert_stmt = [insertSQL UTF8String];
		const char *sqlStatement = "SELECT * FROM health_topic";
		if(sqlite3_prepare_v2(database, sqlStatement, -1, &statement, nil)== SQLITE_OK)
		{
			NSLog(@"added");
			//	 sqlite3_bind_text(statement, 1, [str UTF8String], -1, NULL);
			while(sqlite3_step(statement)==SQLITE_ROW) 
			{
//				NSString *aDate = [NSString stringWithUTF8String:(char *)sqlite3_column_text(statement, 0)];
				NSString *ID = [NSString stringWithUTF8String:(char *)sqlite3_column_text(statement,1)];
                NSString *topic = [NSString stringWithUTF8String:(char *)sqlite3_column_text(statement,3)];
//				int rowid = sqlite3_column_int(statement,2);
//				[ID addObject:[NSNumber numberWithInt:rowid]];
				//data = [data stringByAppendingFormat:@"Speed:%@",aSpeed];
				[arrID addObject:ID];
				[arrGettitleList addObject:topic];
				
			}
			
			
		}
		
		// Release the compiled statement from memory
		sqlite3_finalize(statement);    
		sqlite3_close(database);
	}
    [HUD hide:YES];

}
-(void)getDiscription:(NSString*)title
{
    
    getCount=NO;
    getTitle = NO;
    getDiscription =YES;
//    recordResults=FALSE;
//    if ([delegate isConnected]) 
//    {  
//        NSString *strurl = [NSString stringWithFormat:@"http://wsearch.nlm.nih.gov/ws/query?db=healthTopics&retmax=1&term=%@",title];
//        strurl =[strurl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
//        NSURL *url = [NSURL URLWithString:strurl];
//        NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url];
//        
//        
//        NSURLConnection *theConnection = [[NSURLConnection alloc] initWithRequest:theRequest delegate:self];
//        
//        if( theConnection )
//        {
//            webData = [[NSMutableData data] retain];
//            //            [theConnection release];
//        }
//        else
//        {
//            NSLog(@"theConnection is NULL");
//        }
//        
//    }
//    else
//    {
//        
//		UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Error Loading" message:@"No Internet connection." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//		[alert show];
//		[alert release];
//    }
    sqlite3 *database;
    sqlite3_stmt *statement;
    NSArray *documentPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDir = [documentPaths objectAtIndex:0];
    NSString *databasePath=[documentsDir stringByAppendingPathComponent:@"health_db.sqlite"];
	NSLog(@"%@",databasePath);
	if(sqlite3_open([databasePath UTF8String], &database) == SQLITE_OK)
	{
		//	NSString *insertSQL = [NSString stringWithFormat:@"SELECT * FROM SpeedTrap" ];
		//        NSString *insertSQL = [NSString stringWithFormat: @"INSERT INTO Loginchk (uname,password) VALUES ('%@',' %@');",Gunameq,Gpassq];
		//const char *insert_stmt = [insertSQL UTF8String];
		const char *sqlStatement = "SELECT * FROM health_topic where topic=?";
		if(sqlite3_prepare_v2(database, sqlStatement, -1, &statement, nil)== SQLITE_OK)
		{
			NSLog(@"added");
				 sqlite3_bind_text(statement, 1, [title UTF8String], -1, NULL);
			while(sqlite3_step(statement)==SQLITE_ROW) 
			{
                //				NSString *aDate = [NSString stringWithUTF8String:(char *)sqlite3_column_text(statement, 0)];
				strTopicUrl = [NSString stringWithUTF8String:(char *)sqlite3_column_text(statement,0)];
                strDiscriptionDetail = [NSString stringWithUTF8String:(char *)sqlite3_column_text(statement,2)];
                //				int rowid = sqlite3_column_int(statement,2);
                //				[ID addObject:[NSNumber numberWithInt:rowid]];
				//data = [data stringByAppendingFormat:@"Speed:%@",aSpeed];
				[webview loadHTMLString:strDiscriptionDetail baseURL:[NSURL URLWithString:@"file:///."]];
				
			}
			
			
		}
		
		// Release the compiled statement from memory
		sqlite3_finalize(statement);    
		sqlite3_close(database);
	}
    [arrTempURL addObject:strTopicUrl];
    [arrTempSummary addObject:strDiscriptionDetail];
    [arrTempTitle addObject:searchbar.text];
    curruntIndex = arrTempSummary.count-1;
    btnGoForward.enabled = NO;
    [HUD hide:YES];


}

#pragma mark - xmlParserDelegate method

-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
	[webData setLength: 0];
    CGFloat size = [[NSString stringWithFormat:@"%lli",[response expectedContentLength]] floatValue];
    NSLog(@"Size : %f",size);
}
-(void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    NSLog(@"GEtData");
	[webData appendData:data];
    totalDownloadedData += [data length]; // global integer
    NSLog(@"Status : %d",totalDownloadedData);
}
-(void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    [HUD hide:YES];
	NSLog(@"ERROR with theConenction");
	[connection release];
	[webData release];
}
-(void)connectionDidFinishLoading:(NSURLConnection *)connection
{
	NSLog(@"DONE. Received Bytes: %d", [webData length]);
	NSString *theXML = [[NSString alloc] initWithBytes: [webData mutableBytes] length:[webData length] encoding:NSUTF8StringEncoding];
	NSLog(@"%@",theXML);
	[theXML release];
	
	if( xmlParser )
	{
		[xmlParser release];
	}
	
	xmlParser = [[NSXMLParser alloc] initWithData: webData];
	[xmlParser setDelegate:self];
	[xmlParser setShouldResolveExternalEntities: YES];
	[xmlParser parse];
	
	[connection release];
	[webData release];
}

-(void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *) namespaceURI qualifiedName:(NSString *)qName
   attributes: (NSDictionary *)attributeDict
{
    if (getCount==YES)
    {
        if( [elementName isEqualToString:@"MedicalTopic"])
        {
            
            if ([attributeDict valueForKey:@"langcode"])
            {
                
                strLangageCode = [NSString stringWithFormat:@"%@",[attributeDict valueForKey:@"langcode"]];
                
                    if(!soapResults)
                    {
                        soapResults = [[NSMutableString alloc] init];
                      }
            }
            recordResults = TRUE;
        }
        if( [elementName isEqualToString:@"ID"])
        {
            if(!soapResults)
            {
                soapResults = [[NSMutableString alloc] init];
                
            }
            recordResults = TRUE;
        }

        if( [elementName isEqualToString:@"MedicalTopicName"])
        {
            if(!soapResults)
            {
                soapResults = [[NSMutableString alloc] init];
                
            }
            recordResults = TRUE;
        }

        if( [elementName isEqualToString:@"URL"])
        {
            if(!soapResults)
            {
                soapResults = [[NSMutableString alloc] init];
                
            }
            recordResults = TRUE;
        }

        if( [elementName isEqualToString:@"FullSummary"])
        {
            if(!soapResults)
            {
                soapResults = [[NSMutableString alloc] init];
                
            }
            recordResults = TRUE;
        }
        if( [elementName isEqualToString:@"LanguageMappedTopicID"])
        {
            if(!soapResults)
            {
                soapResults = [[NSMutableString alloc] init];
                
            }
            recordResults = TRUE;
        }

       
        
    }
    else if (getTitle==YES)
    {
        if( [elementName isEqualToString:@"content"])
        {
            if ([attributeDict valueForKey:@"name"])
            {
                NSLog(@"atribute%@",attributeDict);  
                strFetchData = [NSString stringWithFormat:@"%@",[attributeDict valueForKey:@"name"]];
                
                if(!soapResults)
                {
                    soapResults = [[NSMutableString alloc] init];
                    
                }
                
            }
            recordResults = TRUE;
        }
        if( [elementName isEqualToString:@"nlmSearchResult"])
        {
            if(!soapResults)
            {
                soapResults = [[NSMutableString alloc] init];
                
            }
            recordResults = TRUE;
        }


    }
    else if (getDiscription==YES)
    {
        if( [elementName isEqualToString:@"content"])
        {
            if ([attributeDict valueForKey:@"name"])
            {
                NSLog(@"atribute%@",attributeDict);  
                strFetchData = [NSString stringWithFormat:@"%@",[attributeDict valueForKey:@"name"]];
                
                if(!soapResults)
                {
                    soapResults = [[NSMutableString alloc] init];
                    
                }
                
            }
            recordResults = TRUE;
        }
        if( [elementName isEqualToString:@"nlmSearchResult"])
        {
            if(!soapResults)
            {
                soapResults = [[NSMutableString alloc] init];
                
            }
            recordResults = TRUE;
        }
        
        
    }

    
    
}
-(void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
	if( recordResults )
	{
        [soapResults appendString: string];
	}
}
-(void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
    
    if (getCount==YES)
    {
        if ([strLangageCode isEqualToString:@"English" ]) 
        {
            if( [elementName isEqualToString:@"ID"])
            {
                NSLog(@"ID : %@",soapResults);
                [soapResults release];
                soapResults = nil;
                recordResults = FALSE;
            }
            if( [elementName isEqualToString:@"MedicalTopicName"])
            {
                //            strCount = [NSString stringWithString:soapResults];
                NSLog(@"MedicalTopicName = %@",soapResults);
                [soapResults release];
                soapResults = nil;
                recordResults = FALSE;
            }
            
            if( [elementName isEqualToString:@"URL"])
            {
                NSLog(@"URL = %@",soapResults);
                [soapResults release];
                soapResults = nil;
                recordResults = FALSE;
                //            NSMutableArray *temp =[[NSUserDefaults standardUserDefaults] objectForKey:@"title"];
                //            if (temp.count>0) {
                //                arrGettitleList = [[NSUserDefaults standardUserDefaults] objectForKey:@"title"];
                //            }
                //            
                //            NSLog(@"adjskfhdakjsfgadksjgfkjadsgbfkjdsagfk:%@",arrGettitleList);
                //            if (arrGettitleList.count!=[strCount intValue]) 
                //            {
                //                [self getTitleList];
                //            }
                //            else
                //            {
                //                
                //                [HUD hide:YES];
                //            }
                
            }
            
            if( [elementName isEqualToString:@"FullSummary"])
            {
                NSLog(@"summry:%@",soapResults);
                [soapResults release];
                soapResults = nil;
                recordResults = FALSE;
                
            }

            if( [elementName isEqualToString:@"LanguageMappedTopicID"])
            {
                [soapResults release];
                soapResults = nil;
                recordResults = FALSE;
                              
            }


        }
                

    }
    
    else if (getTitle==YES)
    {
        
        if( [elementName isEqualToString:@"content"])
        {
            NSLog(@"temp :%@",strFetchData);
            if ([strFetchData isEqualToString:@"title"])
            {
                NSLog(@"result:%@",soapResults);
                [arrGettitleList addObject:soapResults];
                
            }
            [soapResults release];
            soapResults = nil;
            recordResults = FALSE;
        }
        else if( [elementName isEqualToString:@"nlmSearchResult"])
        {
           
            [[NSUserDefaults standardUserDefaults] setObject:arrGettitleList forKey:@"title"];
            [HUD hide:YES];
            [soapResults release];
            soapResults = nil;
            recordResults = FALSE;
        }
        else
        {
            [soapResults release];
            soapResults = nil;
            recordResults = FALSE;
        }


    }
    else if (getDiscription==YES)
    {
        
        if( [elementName isEqualToString:@"content"])
        {
            NSLog(@"temp :%@",strFetchData);
            if ([strFetchData isEqualToString:@"FullSummary"])
            {
                NSLog(@"result:%@",soapResults);
                strDiscriptionDetail = [NSString stringWithString:soapResults];
            }
            [soapResults release];
            soapResults = nil;
            recordResults = FALSE;
        }
        else if( [elementName isEqualToString:@"nlmSearchResult"])
        {
            
            [arrWebViewData addObject:strDiscriptionDetail];
            [webview loadHTMLString:strDiscriptionDetail baseURL:[NSURL URLWithString:@"file:///."]];
             [soapResults release];
            soapResults = nil;
            recordResults = FALSE;
        }
        else
        {
            [soapResults release];
            soapResults = nil;
            recordResults = FALSE;
        }
        
        
    }

        
    
}
-(BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType; 
{
    NSURL *requestURL =[ [ request URL ] retain ]; 
    if ( ( [ [ requestURL scheme ] isEqualToString: @"http" ] || [ [ requestURL scheme ] isEqualToString: @"https" ] || [ [ requestURL scheme ] isEqualToString: @"mailto" ]) 
        && ( navigationType == UIWebViewNavigationTypeLinkClicked ) ) { 
//        return ![ [ UIApplication sharedApplication ] openURL: [ requestURL autorelease ] ]; 
        WebViewController *objWebViewController= [[WebViewController alloc]initWithNibName:@"WebViewController" bundle:nil];
        objWebViewController.strUrl = [requestURL absoluteString];
        UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:objWebViewController];
        
        [self presentModalViewController:nav animated:YES];
        [objWebViewController release];
        
        return NO;
    } 
    else
    {
        return YES;
    }
    [ requestURL release ]; 
     
}
-(void)webViewDidStartLoad:(UIWebView *)webView
{
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
}
-(void)webViewDidFinishLoad:(UIWebView *)webView
{
    [HUD hide:YES];
    btnAction.enabled =YES;
    if (arrTempSummary.count==1) {
        btnGoBack.enabled = NO;
        btnGoForward.enabled = NO;
    }
    else if (arrTempSummary.count>1)
    {
        btnGoBack.enabled = YES;
    }
    if (curruntIndex==0) {
        btnGoBack.enabled = NO;
    }
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
    webview.scalesPageToFit = YES;
}
- (IBAction)goToBack:(id)sender 
{
    webview.scalesPageToFit = NO;
    curruntIndex=curruntIndex-1;
    if (curruntIndex==0) {
        btnGoBack.enabled = NO;
        btnGoForward.enabled =YES;
    }
    else if(curruntIndex>0 && curruntIndex<arrTempURL.count-1)
    {
        btnGoForward.enabled =YES;
    }
    strTopicUrl = [arrTempURL objectAtIndex:curruntIndex];
    searchbar.text = [arrTempTitle objectAtIndex:curruntIndex];
    [webview loadHTMLString:[arrTempSummary objectAtIndex:curruntIndex] baseURL:[NSURL URLWithString:@"file:///."]];
}

- (IBAction)goToForward:(id)sender
{
    webview.scalesPageToFit = NO;
    curruntIndex = curruntIndex+1;
    if (curruntIndex==[arrTempSummary count]-1) {
        btnGoForward.enabled = NO;
        btnGoBack.enabled = YES;
    }
    strTopicUrl = [arrTempURL objectAtIndex:curruntIndex];
    searchbar.text = [arrTempTitle objectAtIndex:curruntIndex];
    [webview loadHTMLString:[arrTempSummary objectAtIndex:curruntIndex] baseURL:[NSURL URLWithString:@"file:///."]];
}
#pragma mark - tableViewDelegate method
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    // Return the number of rows in the section.
    if (resultList==YES)
    {
        return [arrSelectedtitleList count];
    }
    else
    {
    return [arrSearchtitleList count];
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier] autorelease];
    
            
    }
    if (resultList==YES)
    {
        if (arrSelectedtitleList.count !=0) 
        {
            NSLog(@"%i",indexPath.row);
            cell.textLabel.text = [arrSelectedtitleList objectAtIndex:indexPath.row];
            
        }
        
    }
    else
    {
        if (arrSearchtitleList.count !=0) 
        {
            cell.textLabel.text = [arrSearchtitleList objectAtIndex:indexPath.row];
        }
        
    }

    // Configure the cell...
   
      
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (resultList == YES)
    {
        strSelectedtitle = [NSString stringWithString:[arrSelectedtitleList objectAtIndex:indexPath.row]];
        searchbar.text = strSelectedtitle;
    }
    else
    {
        NSMutableArray *temp =[[NSUserDefaults standardUserDefaults] mutableArrayValueForKey:@"selectTitle"];
        strSelectedtitle = [NSString stringWithString:[arrSearchtitleList objectAtIndex:indexPath.row]];
        [temp addObject:strSelectedtitle];
        [[NSUserDefaults standardUserDefaults] setObject:temp forKey:@"selectTitle"];
        arrSelectedtitleList = [[[NSUserDefaults standardUserDefaults] mutableArrayValueForKey:@"selectTitle"] retain];
        searchbar.text = strSelectedtitle;
    }
    searchbar.showsCancelButton= NO;
    tblView.hidden =YES;
    webview.hidden = NO;
    webview.scalesPageToFit = NO;
    imgViewLogo.hidden =YES;
    tollBarView.hidden =NO;
    btnMic.frame = CGRectMake(276, 0, 44, 44);
    searchbar.frame = CGRectMake(0,0, 276, 44);
    tblView.frame = CGRectMake(0, 44, 320, 372);
    webview.frame = CGRectMake(0, 44, 320, 372);
    [searchbar resignFirstResponder];
    [self getDiscription:strSelectedtitle];
}
-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (resultList==YES) 
    {
        [arrSelectedtitleList removeObjectAtIndex:indexPath.row];
        [self.tblView reloadData];
    }
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return YES if you want the specified item to be editable.
    if (resultList== YES) {
        return YES;
    }
    else
    {
        return NO;
    }
    
}
#pragma mark - SearchBarDelegate method
- (void) searchBarTextDidBeginEditing:(UISearchBar *)theSearchBar {
	webview.hidden =YES;
    tblView.hidden =NO;
    resultList = NO;
    [tblView reloadData];
	//Add the overlay view.
	if(ovController == nil)
		ovController = [[OverlayViewController alloc] initWithNibName:@"OverlayView" bundle:[NSBundle mainBundle]];
	
	CGFloat yaxis = self.navigationController.navigationBar.frame.size.height;
	CGFloat width = self.view.frame.size.width;
	CGFloat height = self.view.frame.size.height;
	
	//Parameters x = origion on x-axis, y = origon on y-axis.
	CGRect frame = CGRectMake(0, yaxis, width, height);
	ovController.view.frame = frame;	
	ovController.view.backgroundColor = [UIColor grayColor];
	ovController.view.alpha = 0.5;
	
	ovController.rvController = self;
	
	[self.tblView insertSubview:ovController.view aboveSubview:self.parentViewController.view];
	searchbar.showsCancelButton = TRUE;
	
	
	self.tblView.scrollEnabled = NO;
	resultList = NO;
    if (searchbar.text.length>2) {
        [self searchTableView];
    }  
	//Add the done button.
		
}
- (void)searchBar:(UISearchBar *)theSearchBar textDidChange:(NSString *)searchText {
	
	//Remove all objects first.
	
	
	if([searchText length] > 2) {
		[ovController.view removeFromSuperview];
		//searchBar.showsCancelButton = FALSE;
		
		self.tblView.scrollEnabled = YES;
		[self searchTableView];
	}
	else {
		
		[self.tblView insertSubview:ovController.view aboveSubview:self.parentViewController.view];
		searchbar.showsCancelButton = TRUE;
		
		self.tblView.scrollEnabled = NO;
	}
	
    //	[self.tblview reloadData];
}
-(void)searchBarResultsListButtonClicked:(UISearchBar *)searchBar
{
    searchbar.showsCancelButton =NO;
    [searchbar resignFirstResponder];
    arrSelectedtitleList = [[[NSUserDefaults standardUserDefaults] mutableArrayValueForKey:@"selectTitle"] retain];
    if (arrSelectedtitleList.count>0) 
    {
        NSArray *copy = [arrSelectedtitleList copy];
        
        NSInteger index = [copy count] - 1;
        
        for (id object in [copy reverseObjectEnumerator]) {
            
            if ([arrSelectedtitleList indexOfObject:object inRange:NSMakeRange(0, index)]!= NSNotFound) 
            {
                [arrSelectedtitleList removeObjectAtIndex:index];
                
            }
            
            index--;
        }
        [copy release];
    }
    
    resultList = YES;
    webview.hidden= YES;
    tblView.hidden = NO;
    [self.tblView reloadData];
}
-(void) searchBarCancelButtonClicked:(UISearchBar *)theSearchBar
{
    tblView.hidden = YES;
    webview.hidden =YES;
	searchbar.text = @"";
	[searchbar resignFirstResponder];
	
	
	self.tblView.scrollEnabled = YES;
	
	[ovController.view removeFromSuperview];
    //	[ovController release];
    //	ovController = nil;
	searchbar.showsCancelButton = FALSE;
	[self.tblView reloadData];
}

- (void) searchBarSearchButtonClicked:(UISearchBar *)theSearchBar {
	
//	[self searchTableView];
    [ovController.view removeFromSuperview];
    //searchBar.showsCancelButton = FALSE;
    
    self.tblView.scrollEnabled = YES;

	[searchbar resignFirstResponder];
    searchbar.showsCancelButton = NO;
    imgViewLogo.hidden =YES;
    tollBarView.hidden =NO;
    btnMic.frame = CGRectMake(276, 0, 44, 44);
    searchbar.frame = CGRectMake(0,0, 276, 44);
    tblView.frame = CGRectMake(0, 44, 320, 372);
    webview.frame = CGRectMake(0, 44, 320, 372);
	//[self doneSearching_Clicked:self];
}

- (void) searchTableView {
    NSString *searchText = searchbar.text;
//	NSLog(@"sdasdasdsadasdasd%@ ",tilesSearch);
	[arrSearchtitleList removeAllObjects];
    
	for (int i=0; i<[arrGettitleList count];i++) {
		NSString *sTemp = [arrGettitleList objectAtIndex:i];
        
        
        NSComparisonResult result = [sTemp compare:searchText options:(NSCaseInsensitiveSearch|NSDiacriticInsensitiveSearch) range:NSMakeRange(0, [searchText length])];
        if (result == NSOrderedSame)
        {
            [arrSearchtitleList addObject:sTemp];
        }
    }
	NSLog(@"serch %@",arrSearchtitleList);
//    if (![arrSearchtitleList count]==0) {
        [self.tblView reloadData];
//    }
	
	
	
	
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [self setBtnZoomOut:nil];
    [self setTollBarView:nil];
    [btnMic release];
    btnMic = nil;
    [self setBtnAction:nil];
    [self setBtnGoForward:nil];
    [self setBtnGoBack:nil];
    [self setImgViewLogo:nil];
    [self setWebview:nil];
    [self setSearchbar:nil];
    [self setTblView:nil];
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [tblView release];
    [searchbar release];
    [webview release];
    [imgViewLogo release];
    [btnGoBack release];
    [btnGoForward release];
    [btnAction release];
    [btnMic release];
    [tollBarView release];
    [btnZoomOut release];
    [super dealloc];
}


- (IBAction)settinButtonClick:(id)sender 
{
    ContactViewController *objContactViewController = [[ContactViewController alloc]initWithNibName:@"ContactViewController" bundle:nil];
    UINavigationController *navigation = [[UINavigationController alloc]initWithRootViewController:objContactViewController];
    [self presentModalViewController:navigation animated:YES];
    [objContactViewController release];
}

- (IBAction)actionButtonClick:(id)sender
{
    UIActionSheet *actionSheet = [[UIActionSheet alloc]initWithTitle:nil delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:@"Open in Safari" otherButtonTitles:@"Email",nil];
    [actionSheet showInView:self.view];
    [actionSheet release];
}
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSString *temp = [NSString stringWithString:strSelectedtitle];
    temp = [temp stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    
    if (buttonIndex==0) 
    {
        NSLog(@"safari:%i",buttonIndex);
        NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@",strTopicUrl]];

                [[UIApplication sharedApplication] openURL:url];
    }
    else if (buttonIndex == 1)
    {
        NSLog(@"email:%i",buttonIndex);
//        [actionSheet removeFromSuperview];
        if ([MFMailComposeViewController canSendMail])
        {
            MFMailComposeViewController *mailPicker = [[MFMailComposeViewController alloc]init];
            mailPicker.mailComposeDelegate = self;
            NSString *emailBody = [NSString stringWithFormat:@"%@",strTopicUrl];
            [mailPicker setMessageBody:emailBody isHTML:NO];
            
            [self presentModalViewController:mailPicker animated:YES];
        }
        else
        {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Please Configure mail Account" message:nil delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            [alert show];
            [alert release];

        }
        
        
    }
    else
    {
        
    }
        
}

- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error 
{	
	
	// Notifies users about errors associated with the interface
	switch (result)
	{
		case MFMailComposeResultCancelled:
        {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"canceled" message:nil delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            [alert show];
            [alert release];
			
        }
			break;
		case MFMailComposeResultSaved:
        {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"saved" message:nil delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            [alert show];
            [alert release];
			
        }
			
			break;
		case MFMailComposeResultSent:
        {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"sent" message:nil delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            [alert show];
            [alert release];
			
        }
			
			break;
		case MFMailComposeResultFailed:
        {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"failed" message:nil delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            [alert show];
            [alert release];
			
        }
			
			break;
		default:
        {
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"not sent" message:nil delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            [alert show];
            [alert release];
			
        }
			
			break;
	}
    [self dismissModalViewControllerAnimated:YES];
    
    //	[self.view removeFromSuperview];
}

- (IBAction)btnMicClick:(id)sender 
{
    [[[HealthInformationAppDelegate appDelegate] iSpeech] ISpeechSilenceDetectAfter:2.5 forDuration:2.0];
	
	NSError *error = nil;
	
	if(![[[HealthInformationAppDelegate appDelegate] iSpeech] ISpeechStartListenWithError:&error]) {
		if([error code] == kISpeechErrorCodeNoInternetConnection) {
			UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"You are not connected to the Internet. Please double check your connection settings." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
			[alert show];
			[alert release];
		} else if([error code] == kISpeechErrorCodeNoInputAvailable) {
			UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"No audio input available. Please plug in a microphone to use speech recognition." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
			[alert show];
			[alert release];
		}
	}

}
- (void)ISpeechDelegateFinishedRecognize:(ISpeechSDK *)ispeech withStatus:(NSError *)status result:(NSString *)text {
	if(status) {
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:[status localizedDescription] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
		[alert show];
		[alert release];
	}
	
	searchbar.text = text;
}
- (IBAction)btnZoomInClick:(id)sender 
{
    btnMic.hidden = YES;
    searchbar.hidden = YES;
    tollBarView.hidden = YES;
    btnZoomOut.hidden = NO;
    webview.frame = CGRectMake(0, 0, 320, 460);
}

- (IBAction)btnZoomOutClick:(id)sender 
{
    btnMic.hidden = NO;
    searchbar.hidden = NO;
    tollBarView.hidden = NO;
    btnZoomOut.hidden = YES;
    webview.frame = CGRectMake(0, 44, 320, 372);
}
@end
