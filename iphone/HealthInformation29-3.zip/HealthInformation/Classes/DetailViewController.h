//
//  DetailViewController.h
//  HealthInformation
//
//  Created by Ramesh Patel on 3/28/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController

@end
