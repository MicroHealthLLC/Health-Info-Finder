//
//  SplashViewController.h
//  HealthInformation
//
//  Created by Ramesh Patel on 3/10/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TFHpple.h"
#import "HealthInformationAppDelegate.h"
#import "sqlite3.h"
#import "MBProgressHUD.h"
#import <unistd.h>
@class HealthInformationAppDelegate;
@interface SplashViewController : UIViewController<UIAlertViewDelegate,NSXMLParserDelegate>
{
    NSXMLParser *xmlParser;
    NSMutableData *webData;
	NSMutableString *soapResults;
    BOOL *recordResults;
    sqlite3 *database;
	sqlite3_stmt *statement;
    HealthInformationAppDelegate *delegate;
    NSString *strCompletedataUrl;
    NSString *strModifiDataUrl;
    NSString *strLangageCode;
    int totalDownloadedData;
    CGFloat size;
    NSString *strID;
    NSString *strUrl;
    NSString *strTopic;
    NSString *strSummury;
    MBProgressHUD *HUD;
    BOOL getUpgate;
    NSString *strUpdateCount;
    NSString *strUpdateStatus;
    IBOutlet UIActivityIndicatorView *activity;
}
@property (retain, nonatomic) IBOutlet UIProgressView *progressBar;
@property(nonatomic, retain) NSMutableData *webData;
@property(nonatomic, retain) NSMutableString *soapResults;
@property(nonatomic, retain) NSXMLParser *xmlParser;
-(void)getCount;
-(void)getUpdateData;
@end
