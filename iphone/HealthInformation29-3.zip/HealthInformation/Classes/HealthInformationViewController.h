//
//  HealthInformationViewController.h
//  HealthInformation
//
//  Created by MAC4 on 3/3/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HealthInformationAppDelegate.h"
#import "MBProgressHUD.h"
#import "WebViewController.h"
#import <unistd.h>
#import <MessageUI/MFMailComposeViewController.h>

@class OverlayViewController;
@class HealthInformationAppDelegate;
@interface HealthInformationViewController : UIViewController<NSXMLParserDelegate,MBProgressHUDDelegate,UITableViewDataSource,UITableViewDelegate,UISearchBarDelegate,UISearchDisplayDelegate,UIWebViewDelegate,UIActionSheetDelegate,MFMailComposeViewControllerDelegate,ISpeechDelegate> {
    NSXMLParser *xmlParser;
    NSMutableData *webData;
	NSMutableString *soapResults;
    BOOL *recordResults;
    NSString *strFetchData;
    BOOL getCount;
    BOOL getTitle;
    BOOL getDiscription;
    NSString *strCount;
    NSMutableArray *arrGettitleList;
    NSMutableArray *arrSearchtitleList;
    NSMutableArray *arrID;
    OverlayViewController *ovController;
    HealthInformationAppDelegate *delegate;
    MBProgressHUD *HUD;
    NSString *strSelectedtitle;
    NSMutableArray *arrSelectedtitleList;
    NSString *strDiscriptionDetail;
    BOOL resultList;
    NSMutableArray *arrWebViewData;
    NSString *strCompletedataUrl;
    NSString *strModifiDataUrl;
    NSString *strLangageCode;
    NSString *strTopicUrl;
    NSMutableArray *arrTempSummary;
    NSMutableArray *arrTempTitle;
    NSMutableArray *arrTempURL;
    int curruntIndex;
    BOOL isUrl;
    IBOutlet UIButton *btnMic;
}
- (IBAction)btnZoomInClick:(id)sender;
- (IBAction)btnZoomOutClick:(id)sender;
@property (retain, nonatomic) IBOutlet UIButton *btnZoomOut;
@property (retain, nonatomic) IBOutlet UIToolbar *tollBarView;
- (IBAction)btnMicClick:(id)sender;
@property (retain, nonatomic) IBOutlet UIBarButtonItem *btnAction;
- (IBAction)settinButtonClick:(id)sender;
- (IBAction)actionButtonClick:(id)sender;
@property (retain, nonatomic) IBOutlet UIBarButtonItem *btnGoForward;
@property (retain, nonatomic) IBOutlet UIBarButtonItem *btnGoBack;
- (IBAction)goToBack:(id)sender;
- (IBAction)goToForward:(id)sender;
@property (retain, nonatomic) IBOutlet UIImageView *imgViewLogo;
@property (retain, nonatomic) IBOutlet UIWebView *webview;
@property (retain, nonatomic) IBOutlet UISearchBar *searchbar;
@property (retain, nonatomic) IBOutlet UITableView *tblView;
@property(nonatomic, retain) NSMutableData *webData;
@property(nonatomic, retain) NSMutableString *soapResults;
@property(nonatomic, retain) NSXMLParser *xmlParser;

-(void)getCount;
-(void)getTitleList;
- (void)searchTableView;
-(void)getDiscription:(NSString*)title;
-(void)getUrls;
-(void)getDataFomDatabase;
@end

