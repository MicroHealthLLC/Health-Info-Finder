//
//  HealthInformationAppDelegate.h
//  HealthInformation
//
//  Created by MAC4 on 3/3/12.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SystemConfiguration/SystemConfiguration.h>  
#import <netinet/in.h>  
#import <arpa/inet.h>  
#import <netdb.h> 
#import "sqlite3.h"
#import "ISpeechSDK.h"
@class SplashViewController;

@interface HealthInformationAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    UINavigationController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet UINavigationController *viewController;
@property (nonatomic, retain, readonly) ISpeechSDK *iSpeech;

+ (HealthInformationAppDelegate *)appDelegate;
- (BOOL) isConnected;
- (void)createEditableCopyOfDatabaseIfNeeded;
@end

